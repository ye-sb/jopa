<?php

class controller_news extends Controller
{
    function __construct()
    {
        $this->model = new model_news();
        $this->view = new View();
    }

    function action_add()
    {
        $model = $this->model;
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $model->title = isset($_POST['title']) ? $_POST['title'] : null;
            $model->short_description = isset($_POST['short_description']) ? $_POST['short_description'] : null;
            $model->full_description = isset($_POST['full_description']) ? $_POST['full_description'] : null;
            $model->img = isset($_POST['img']) ? $_POST['img'] : null;
            $model->addInfo();
            return $this->view->generate(
                'main_view.php',
                'template_view.php',
                ['model' => $model]
            );
        }
        $this->view->generate('main_view.php', 'template_view.php', ['model' => $model]);
    }


}
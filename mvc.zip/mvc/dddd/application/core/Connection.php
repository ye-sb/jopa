<?php


class Connection
{
    public function create()
    {
        $conn = new mysqli('localhost', "root", "", "news");
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }

        return $conn;
    }
}

<?php
    echo <<<HTML
<h2>Добавлено</h2>
<hr>
HTML;


<?php
/** @var model_news $model */

if (!empty($model->errors)) {
    echo "Имееются ошибки<br>";
    foreach ($model->errors as $key => $error) {
        echo "<p>Поле: $key Ошибка: $error </p><br>";
    }
}
?>

<form action="/news/add/" method="post">
    <input type="text" class="title" name="title" placeholder="Заголовок новости" value="<?= $model->title ?>">
    <br><textarea type="text" class="short_description" row="30" columns="30" name="short_description"
                  placeholder="Краткое описание новости"><?= $model->short_description ?></textarea>
    <br><textarea type="text" class="full_description " row="60" columns="60" name="full_description"
                  placeholder="Подробное описание новости "><?= $model->full_description ?></textarea><br>

    <p>Загрузите фото :</p>
    <input type="text" name="img" value="<?= $model->img ?>">
    <br> <input type="submit" value="Загрузить">
</form>
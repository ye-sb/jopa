<!DOCTYPE html>
<html lang="ru">
<head>
    <link rel="stylesheet" type="text/css" href="/css/style.css"/>
    <meta charset="utf-8">
    <title>Главная</title>
</head>
<body>
<?php include 'application/views/' . $content_view; ?>
<script src="/js/jquery-1.6.2.js" type="text/javascript"></script>
</body>
</html>
<?php

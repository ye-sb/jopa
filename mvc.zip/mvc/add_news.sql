-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Хост: 127.0.0.1:3306
-- Время создания: Дек 14 2019 г., 14:27
-- Версия сервера: 8.0.15
-- Версия PHP: 7.1.32

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `news`
--

-- --------------------------------------------------------

--
-- Структура таблицы `add_news`
--

CREATE TABLE `add_news` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `short_description` text NOT NULL,
  `full_description` text NOT NULL,
  `img` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `add_news`
--

INSERT INTO `add_news` (`id`, `title`, `short_description`, `full_description`, `img`) VALUES
(2, 'sdasdasd', 'asdadsa', 'asdasd', 'asdasd'),
(3, 'sdasdasd', 'asdadsa', 'asdasd', 'asdasd'),
(7, 'ааа', 'ааа', 'ааа', 'https://yandex.ru/images/search?from=tabbar&text=%D0%B1%D1%82%D1%81&pos=3&img_url=https%3A%2F%2Fwww.kpopwiki.net%2Fwp-content%2Fuploads%2F2019%2F04%2Fbts-map-of-the-soul-new-album-1.jpg&rpt=simage'),
(8, 'fsdfds', 'fdsfds', 'fdsf', 'dsfasdf'),
(9, 'fsdfds', 'fdsfds', 'fdsf', 'dsfasdf'),
(10, 'ds123', '123', '123', '123'),
(11, 'yrtyrt', 'yrtytr', 'yrtyrty', 'ytryrty'),
(12, '155', '155', '155', '155');

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `add_news`
--
ALTER TABLE `add_news`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `add_news`
--
ALTER TABLE `add_news`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
